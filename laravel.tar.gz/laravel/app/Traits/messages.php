<?php

 namespace App\Traits;
 
 
 trait messages
{
	public $OffDate ='   شما خارج از زمان تعیین شده مراجعه کرده اید  &nbsp;&nbsp;' ;
	public $LoginNeeded = ' &nbsp;  &nbsp; لطفا ابتدا در وب سایت ثبت نام کنید  &nbsp; &nbsp;';
	public $ReloginNeeded ='لطفا دوباره وارد شوید- خطایی رویداد';
	public $PureInteger = ' فقط از اعداد استفاده کنید ';
	public $Successfull = ' &nbsp;با موفقیت انجام شد &nbsp;&nbsp; ';
	public $ProcessEnded = '  فرایند&nbsp;پایان&nbsp;&nbsp; ';              
	public $Payment = '    پرداخت هزینه ثبت نام&nbsp;&nbsp; ';
	public $AlreadyDone = ' شما از این مرحله عبور کرده بودید تنظیمات قبلی ذخیره شده است&nbsp;&nbsp;';
}	
?>
                  