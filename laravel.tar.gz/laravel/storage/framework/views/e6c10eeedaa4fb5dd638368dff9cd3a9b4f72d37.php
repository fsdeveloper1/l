<?php $__env->startSection('content'); ?>
<br/><br/>


      <!--h-->

	  
<div class="container" id="d"><style>#d{border:solid 1.5px; font-size:140%;}</style>
  <h2>مشخصات خود را تایید می کنید؟</h2>
           
  <table class="table table-striped">
    <thead>
      
    </thead>
    <tbody>
      <tr>
        
        <td><?php echo e($name); ?></td>
		<td >نام</td >
		
      </tr>
      <tr>
        
        <td><?php echo e($lastname); ?></td>
		<td >فامیلی</td>
		
      </tr>
      <tr>
        
        <td><?php echo e($meliNumber); ?></td>
		<td >شماره کارت ملی</td>
		
      </tr>
	    <tr>
        
        <td><?php echo e($phone); ?></td>
		<td >شماره تلفن</td>
		
      </tr>
	    <tr>
       
        <td><?php echo e($address); ?></td>
		 <td >آدرس</td>
		 
      </tr>
	    <tr>
        
        <td><?php echo e($postalcode); ?></td>
		<td >کد پستی</td>
		
      </tr>
	    <tr>
        
        <td><?php echo e($birthdate); ?></td> 
		<td >تولد</td>
		
      </tr>
	 
    </tbody>
  </table>

   							
							
                            <div class="col-md-8 col-md-offset-3">
								<form class="form-horizontal" method="post" 
									  action="<?php echo e(route('FROK')); ?>">
									  <?php echo e(csrf_field()); ?>

									<input type="text "name="confirm" value="true" >
									<button type="submit" class="btn btn-success btn-lg" >
									
										&nbsp;&nbsp;&nbsp;&nbsp; تایید &nbsp;&laquo;&nbsp;&nbsp;&nbsp;
									</button>
								</form>	<style>input{display:none;}</style>
								
							</div><br/><br/>	
				
</div>	
<!--//h-->
<br/><br/><br/><br/>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>