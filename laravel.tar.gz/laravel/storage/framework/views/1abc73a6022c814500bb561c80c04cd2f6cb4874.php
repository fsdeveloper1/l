<?php $__env->startSection('content'); ?>
<style>#m{color:black;padding-right:4%;}@keyframes  imp{to{background-color:#ff0101;}} #m{animation:imp 3.5s;}</style>
<div id="m">
	 &emsp; <h1 > <?php echo e($key); ?> </h1  ><br/>
</div>
<?php if(auth()->guard()->guest()): ?> <style>@keyframes  imo{to{background-color:#ff0101;}}  #d{animation:imo 3.5s 3.5s ;} </style>
<?php endif; ?>
<?php $__env->stopSection(); ?>







<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>