<?php $__env->startSection('content'); ?>
<br/><br/>


      <!--h-->

	  
	
	
<div class="container" id="j">
  <h2></h2>
	
	<img class="img-rounded" src="storage/<?php echo e($image); ?>/fff.jpg" id="img" />  
	
  <table class="table table-striped">
    <thead>
      
    </thead>
    <tbody>
      <tr>
        
        <td><?php echo e($name); ?></td>
		<td >نام</td >
		
      </tr>
      <tr>
        
        <td><?php echo e($lastname); ?></td>
		<td >فامیلی</td>
		
      </tr>
     
	    <tr>
        
        <td><?php echo e($phone); ?></td>
		<td >شماره تلفن</td>
		
      </tr>
	   
    </tbody>
  </table>
  
</div>	

<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>