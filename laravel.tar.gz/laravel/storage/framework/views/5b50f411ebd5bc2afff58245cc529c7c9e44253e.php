<?php $__env->startSection('content'); ?>
<br/>
<div class="container">
    <div class="row">
        <div class="col-md-6 col-md-offset-6">
            <div class="panel panel-default">
                <div class="panel-heading"><h4> برای رورد به صفحه کاربری ثبت نام کنید &nbsp;&nbsp;</h4></div>

                <div class="panel-body">
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('FullRegister')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
						<!--part--><br/>
                            <label for="name" class="col-md-4 control-label lg">نام</label>

                            <div class="col-md-7">
                                <input id="name" type="text" class="form-control input-lg" name="name" value="<?php echo e(old('name')); ?>" maxlength="15" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
							<!--//part--><br/><br/><br/>
							
							<!--part-->
							<label for="lastname" class="col-md-4 control-label">فامیلی</label>

                            <div class="col-md-7">
                                <input id="lastname" type="text" class="form-control input-lg" name="lastname" value="<?php echo e(old('lastname')); ?>" maxlength="25" required autofocus>

                                <?php if($errors->has('lastname')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('lastname')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
						<!--//part-->
						
						<!--checklist-->
							
								<div class="container">
									
										<div class="form-group">
											
												<div class="col-md-2">
													<select class="form-control input-lg" type="select list"   name="sex" id="sex" >
														<option  value="man">مرد</option>
														<option  value="woman">زن</option>
													</select>
												</div>	
										</div>
									
								</div>	
							
							<!--//checklist-->
							
						<!--part-->
                            <label for="meliNumber" class="col-md-4 control-label">شماره کارت ملی</label>

                            <div class="col-md-7">
                                <input id="meliNumber" type="text" class="form-control input-lg"           name="meliNumber" value="<?php echo e(old('name')); ?>" maxlength="10" required autofocus>

                                <?php if($errors->has('meli')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('meli')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
							<!--//part--><br/><br/><br/>
							
							<!--part-->
                            <label for="birthdate" class="col-md-4 control-label">تاریخ تولد</label>

                            <div class="col-md-5">
                                <input id="birthdate" type="date" class="form-control input-lg" name="birthdate" value="<?php echo e(old('birthdate')); ?>" maxlength="11" required autofocus>

                                <?php if($errors->has('date')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('date')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
							<!--//part--><br/><br/><br/>
							
							<!--part-->
                            <label for="phone" class="col-md-4 control-label">تلفن</label>

                            <div class="col-md-7">
                                <input id="phone" type="tel" class="form-control input-lg" name="phone" value="<?php echo e(old('phone')); ?>" maxlength="11" required autofocus>

                                <?php if($errors->has('phone')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('phone')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
							<!--//part--><br/><br/><br/>
							
							<!--part-->
                            <label for="address" class="col-md-4 control-label"> آدرس</label>
                            <div class="col-md-7">
							<textarea id="address" name="address" class="form-control"  rows="3" cols="" value="<?php echo e(old('address')); ?>" maxlength="120" required autofocus ></textarea>
									<br>
 

                                <?php if($errors->has('address')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('address')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
							<!--//part--><br/><br/><br/>
							
							<!--part--><br/><br/><br/>
                            <label for="postalcode" class="col-md-4 control-label">کد پستی</label>

                            <div class="col-md-7">
                                <input id="postalcode" type="text" class="form-control input-lg" name="postalcode" value="<?php echo e(old('postalcode')); ?>" required autofocus>

                                <?php if($errors->has('postalcode')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('postalcode')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div
							<!--//part--><br/><br/><br/>
						<!--btn-->	
                        <div class="form-group">
                            <div class="col-md-5 col-md-offset-3">
                                <button type="submit" class="btn btn-primary btn-lg">
                                    ثبت&nbsp;&lsaquo;
                                </button>
                            </div>
                        </div>
						<!--//btn-->
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>